# ArxisVR - Pacote de identidade visual

Identidade desenvolvida para uma plataforma BIM/3D em nuvem, com foco em clareza espacial, precisão técnica e colaboração.

## Arquivos

- `logos/arxisvr-logo-primary.svg`: assinatura principal para fundos claros.
- `logos/arxisvr-logo-reverse.svg`: assinatura para fundos escuros.
- `logos/arxisvr-logo-mono-dark.svg`: versão monocromática escura.
- `logos/arxisvr-logo-mono-light.svg`: versão monocromática clara.
- `logos/arxisvr-symbol.svg`: símbolo isolado para avatar, favicon e ícone de aplicativo.
- `logos/arxisvr-logo-editable.svg`: versão com wordmark editável em texto.
- `exports/arxisvr-avatar-2048.png`: avatar em alta resolução.
- `exports/arxisvr-symbol-512.png`: ícone em PNG.
- `tokens/arxisvr-colors.css`: variáveis CSS da paleta.
- `tokens/arxisvr-colors.json`: tokens de cor em JSON.
- `guia-marca-arxisvr.pdf`: guia enxuto de aplicação.

## Uso rápido

- Use a assinatura principal em apresentações, landing pages e documentos.
- Use o símbolo isolado apenas quando o nome ArxisVR já estiver visível ou for reconhecível no contexto.
- Preserve a área de proteção e não altere proporções, cores ou espaçamento.

Tagline sugerida: **Modelos conectados. Decisões mais claras.**

